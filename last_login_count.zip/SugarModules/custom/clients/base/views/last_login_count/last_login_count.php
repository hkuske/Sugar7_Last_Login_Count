<?php

/*
 * 
 * 
 * 
 * 
 * 
 * 
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$viewdefs['base']['view']['last_login_count'] = array(
    'dashlets' => array(
        array(
            'label' => 'LBL_LAST_LOGIN_COUNT',
            'description' => 'LBL_LAST_LOGIN_COUNT_DESC',
            'config' => array(
            ),
            'preview' => array(
            ),
            'filter' => array(
            )
        ),
	),
);
