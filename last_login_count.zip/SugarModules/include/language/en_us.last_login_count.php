<?php
// Summen dashlet
$app_strings['LBL_LAST_LOGIN_COUNT'] = "Last logins per interval (admin only)";
$app_strings['LBL_LAST_LOGIN_COUNT_DESC'] = "Shows the last logins per interval";
$app_strings['LBL_LAST_LOGIN_COUNT_DAY'] = "Logins last day:";
$app_strings['LBL_LAST_LOGIN_COUNT_WEEK'] = "Logins last 7 days:";
$app_strings['LBL_LAST_LOGIN_COUNT_MONTH'] = "Logins last 30 days:";
$app_strings['LBL_LAST_LOGIN_COUNT_YEAR'] = "Logins last 365 days:";